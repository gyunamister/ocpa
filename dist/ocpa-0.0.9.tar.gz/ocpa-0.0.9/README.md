# Welcome OCPA

### Object-Centric Process Analysis

### Contributors

- Newyork Adams, M.Sc. Mult.

- Genau Park, M.Sc.

### Vision

- Apes Zusammen ganz stark
