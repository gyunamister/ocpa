from ocpa.objects.log.importer.ocel.versions import import_ocel_xml
from ocpa.objects.log.importer.ocel.versions import import_ocel_json
