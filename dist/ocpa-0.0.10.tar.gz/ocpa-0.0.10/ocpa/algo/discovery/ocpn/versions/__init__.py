from ocpa.algo.discovery.ocpn.versions import inductive_and_tr
