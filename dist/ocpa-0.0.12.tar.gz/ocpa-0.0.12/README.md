# Welcome OCPA

### Object-Centric Process Analysis
