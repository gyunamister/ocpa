import ocpa.objects.log
import ocpa.objects.oc_petri_net
